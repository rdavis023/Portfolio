/*//********************************************************************************
// Name:  [Rahshann Davis]
// FIU email: [rdavi159@fiu.edu]
// PantherID:  [6383037]
// CLASS: COP 2210 – [Fall 2022]
// ASSIGNMENT # [#2]
// DATE: [10/07/22]
//
// I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else.
//********************************************************************************

 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package butterfliesvsbees;
import java.util.Random;
import java.util.Scanner;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
/**
 *
 * @author Rahshann
 */
public class ButterFliesVsBees {

     public static void main(String[] args) {
       Scanner scnr = new Scanner(System.in);
        Random capacity = new Random();
        int playerCapacity;
        int player2Capacity;
        int playerCapacity2;
        int player2Capacity2;
        int playerCapacity3;
        int player2Capacity3;
        int randomCPUsize;
        int numMiles;
        int numMiles2;
        int numMiles3;
        
            playerCapacity = 1 + capacity.nextInt(8);
            player2Capacity = 1 + capacity.nextInt(10);
            playerCapacity2 = 1 + capacity.nextInt(8);
            player2Capacity2 = 1 + capacity.nextInt(10);
            playerCapacity3 = 1 + capacity.nextInt(8);
            player2Capacity3 = 1 + capacity.nextInt(10);
            randomCPUsize = 1 + capacity.nextInt(8);
            numMiles = 1 + capacity.nextInt(5);
            numMiles2 = 1 + capacity.nextInt(5);
            numMiles3 = 1 + capacity.nextInt(5);
            
       
        
        int playerChoice;
        boolean Bees = true;
           
        UserPlayer playerInfo = new UserPlayer();
      
      System.out.print("Enter your name: ");
      playerInfo.setplayerName(scnr.nextLine());
      System.out.print("Choose 1 for Bees or Choose 2 for Butterflies: ");
      playerChoice = scnr.nextInt();
      System.out.print(playerChoice);
      System.out.print(scnr.nextLine());
   
      ButterFlies bfInfo = new ButterFlies();
      Bees beesInfo = new Bees();
      
      if (playerChoice ==1) {
          System.out.println();
          System.out.println();
          System.out.println("   " + playerInfo.getplayerName() + ": Bees");
          System.out.println("         VS");
          System.out.println("Mr. Computer: Butterflies");
          System.out.println();
          System.out.print("Enter Bees' name: ");
          beesInfo.setbeeName(scnr.nextLine());
          System.out.print("Pick a starting size between 1 and 10: ");
          beesInfo.setbeeSize(scnr.nextInt());
          System.out.print(scnr.nextLine());
          
          
          
          
          
      }
      else {
          Bees = false;
           System.out.println();
           System.out.println();
           System.out.println(" " + playerInfo.getplayerName() + ": Butterflies");
           System.out.println("      VS");
           System.out.println("Mr. Computer: Bees");
           System.out.println();
           System.out.print("Enter Butterflies' name: ");
           bfInfo.setbfName(scnr.nextLine());
           System.out.print("What color do you want your butterfly colony Red or Blue? ");
           bfInfo.setbfColor(scnr.nextLine());
           System.out.println("You are now the:  " + bfInfo.getbfColor() + " " + bfInfo.getbfName());
           System.out.print("Pick a starting size between 1 and 10: ");
           bfInfo.setbfSize(scnr.nextInt());
           System.out.print(scnr.nextLine());
      }
      
      
      
        double beepercentLost1 =  ((1 - (numMiles * 0.1)) * playerCapacity);
        double beepercentLost2 =  ((1 - (numMiles2 * 0.1)) * playerCapacity2);
        double beepercentLost3 =  ((1 - (numMiles3 * 0.1)) * playerCapacity3);
      
        double bfpercentLost1 =  ((1 - (numMiles * 0.1)) * player2Capacity);
        double bfpercentLost2 =  ((1 - (numMiles2 * 0.1)) * player2Capacity2);
        double bfpercentLost3 =  ((1 - (numMiles3 * 0.1)) * player2Capacity3);
      
        double cpuBFPercentLost1 =  ((1 - (numMiles * 0.1)) * player2Capacity);
        double cpuBFPercentLost2 =  ((1 - (numMiles2 * 0.1)) * player2Capacity2);
        double cpuBFPercentLost3 =  ((1 - (numMiles3 * 0.1)) * player2Capacity3);
      
        
        double cpuBeePercentLost1 = ((1 - (numMiles * 0.1)) * playerCapacity);
        double cpuBeePercentLost2 = ((1 - (numMiles2 * 0.1)) * playerCapacity2);
        double cpuBeePercentLost3 = ((1 - (numMiles3 * 0.1)) * playerCapacity3);
        
        
        double totalbeePlayerNector1 = ((1 - (numMiles * 0.1)) * playerCapacity);
        double totalbeePlayerNector2 = (beepercentLost1 + beepercentLost2);
        double totalbeePlayerNector3 = (beepercentLost1 + beepercentLost2 + beepercentLost3);
        double totalbfPlayerNector = ((1 - (numMiles * 0.1)) * player2Capacity);
        double totalbfPlayerNector2 = (bfpercentLost1 + bfpercentLost2);
        double totalbfPlayerNector3 = (bfpercentLost1 + bfpercentLost2 + bfpercentLost3);
        
        double totalCPUbeePlayerNector1 = ((1 - (numMiles * 0.1)) * playerCapacity);
        double totalCPUbeePlayerNector2 = (cpuBeePercentLost1 + cpuBeePercentLost2);
        double totalCPUbeePlayerNector3 = (cpuBeePercentLost1 + cpuBeePercentLost2 + cpuBeePercentLost3);
        double totalCPUbfPlayerNector = ((1 - (numMiles * 0.1)) * player2Capacity);
        double totalCPUbfPlayerNector2 = (cpuBFPercentLost1 + cpuBFPercentLost2);
        double totalCPUbfPlayerNector3 = (cpuBFPercentLost1 + cpuBFPercentLost2 + cpuBFPercentLost3);
      
        
      System.out.println();
      System.out.print("What type of flower do you want to represent Flower 1: ");
      playerInfo.setflowerType(scnr.nextLine());
      System.out.print("What color do you want the flower to be: ");
      playerInfo.setflowerColor(scnr.nextLine());
      System.out.print("What type of flower do you want to represent Flower 2: ");
      playerInfo.setflowerType2(scnr.nextLine());
      System.out.print("What color do you want the flower to be: ");
      playerInfo.setflowerColor2(scnr.nextLine());
      System.out.print("What type of flower do you want to represent Flower 3: ");
      playerInfo.setflowerType3(scnr.nextLine());
      System.out.print("What color do you want the flower to be: ");
      playerInfo.setflowerColor3(scnr.nextLine());
     
      
      
      if (playerChoice ==1) {
      
      System.out.println();
      System.out.println();
      System.out.println();
      System.out.println("Round 1! ");
      System.out.println();
      System.out.println("Race to: " + playerInfo.getflowerColor()+ " " + playerInfo.getflowerType());
      System.out.println("Distance is: " + numMiles + " miles");
      System.out.print("Bees carrying capacity: ");
      System.out.print(playerCapacity);
      System.out.println(" grams");
      System.out.print("Butterflies carrying capacity: ");
      System.out.print(player2Capacity);
      System.out.println(" grams");
      System.out.println();
      System.out.print("The Bees made it back with: ");
      System.out.println(beepercentLost1);
      System.out.print("The Butterflies made it back with: ");
      System.out.println(cpuBFPercentLost1);
      System.out.print("Total nector collected for Bees: ");
      System.out.println(totalbeePlayerNector1);
      System.out.print("Total nector collected for Butterflies: ");
      System.out.println(totalCPUbfPlayerNector);
      
      
      
      
      
      
      
      
      
      System.out.println();
      System.out.println();
      System.out.println();
      System.out.println("Round 2! ");
      System.out.println();
      System.out.println("Race to: " + playerInfo.getflowerColor2()+ " " + playerInfo.getflowerType2());
      System.out.println("Distance is: " + numMiles2 + " miles");
      System.out.print("Bees carrying capacity: ");
      System.out.print(playerCapacity2);
      System.out.println(" grams");
      System.out.print("Butterflies carrying capacity: ");
      System.out.print(player2Capacity2);
      System.out.println(" grams");
      System.out.print("The Bees made it back with: ");
      System.out.println(beepercentLost2);
      System.out.print("The Butterflies made it back with: ");
      System.out.println(cpuBFPercentLost2);
      System.out.print("Total nector collected for Bees: ");
      System.out.println(totalbeePlayerNector2 );
      System.out.print("Total nector collected for Butterflies: ");
      System.out.println(totalCPUbfPlayerNector2);
      
      
      
      
      
      
      
      
      System.out.println();
      System.out.println();
      System.out.println();
      System.out.println("Round 3! ");
      System.out.println();
      System.out.println("Race to: " + playerInfo.getflowerColor3()+ " " + playerInfo.getflowerType3());
      System.out.println("Distance is: " + numMiles3 + " miles");
      System.out.print("Bees carrying capacity: ");
      System.out.print(playerCapacity3);
      System.out.println(" grams");
      System.out.print("Butterflies carrying capacity: ");
      System.out.print(player2Capacity3);
      System.out.println(" grams");
      System.out.print("The Bees made it back with: ");
      System.out.println(beepercentLost3);
      System.out.print("The Butterflies made it back with: ");
      System.out.println(cpuBFPercentLost3);  
      System.out.print("Total nector collected for Bees: ");
      System.out.println(totalbeePlayerNector3);
      System.out.print("Total nector collected for Butterflies: ");
      System.out.println(totalCPUbfPlayerNector3);
      
      }
else {
    Bees = false;
    System.out.println();
      System.out.println();
      System.out.println();
      System.out.println("Round 1! ");
      System.out.println();
      System.out.println("Race to: " + playerInfo.getflowerColor()+ " " + playerInfo.getflowerType());
      System.out.println("Distance is: " + numMiles + " miles");
      System.out.print("Bees carrying capacity: ");
      System.out.print(playerCapacity);
      System.out.println(" grams");
      System.out.print("Butterflies carrying capacity: ");
      System.out.print(player2Capacity);
      System.out.println(" grams");
      System.out.println();
      System.out.print("The Bees made it back with: ");
      System.out.println(cpuBeePercentLost1);
      System.out.print("The Butterflies made it back with: ");
      System.out.println(bfpercentLost1);
      System.out.print("Total nector collected for Bees: ");
      System.out.println(totalCPUbeePlayerNector1 );
      System.out.print("Total nector collected for Butterflies: ");
      System.out.println(totalbfPlayerNector);
      
      
      
      
      
      
      
      
      
      System.out.println();
      System.out.println();
      System.out.println();
      System.out.println("Round 2! ");
      System.out.println();
      System.out.println("Race to: " + playerInfo.getflowerColor2()+ " " + playerInfo.getflowerType2());
      System.out.println("Distance is: " + numMiles2 + " miles");
      System.out.print("Bees carrying capacity: ");
      System.out.print(playerCapacity2);
      System.out.println(" grams");
      System.out.print("Butterflies carrying capacity: ");
      System.out.print(player2Capacity2);
      System.out.println(" grams");
      System.out.print("The Bees made it back with: ");
      System.out.println(cpuBeePercentLost2);
      System.out.print("The Butterflies made it back with: ");
      System.out.println(bfpercentLost2);
      System.out.print("Total nector collected for Bees: ");
      System.out.println(totalCPUbeePlayerNector2 );
      System.out.print("Total nector collected for Butterflies: ");
      System.out.println(totalbfPlayerNector2);
      
      
      
      
      
      
      
      
      System.out.println();
      System.out.println();
      System.out.println();
      System.out.println("Round 3! ");
      System.out.println();
      System.out.println("Race to: " + playerInfo.getflowerColor3()+ " " + playerInfo.getflowerType3());
      System.out.println("Distance is: " + numMiles3 + " miles");
      System.out.print("Bees carrying capacity: ");
      System.out.print(playerCapacity3);
      System.out.println(" grams");
      System.out.print("Butterflies carrying capacity: ");
      System.out.print(player2Capacity3);
      System.out.println(" grams");
      System.out.print("The Bees made it back with: ");
      System.out.println(cpuBeePercentLost3);
      System.out.print("The Butterflies made it back with: ");
      System.out.println(bfpercentLost3);  
      System.out.print("Total nector collected for Bees: ");
      System.out.println(totalCPUbeePlayerNector3 );
      System.out.print("Total nector collected for Butterflies: ");
      System.out.println(totalbfPlayerNector3);
}
     
     
    double bfpopulationLost = (bfInfo.getbfSize()- (bfInfo.getbfSize() * 0.1));
    double beepopulationLost = (beesInfo.getbeeSize() - (beesInfo.getbeeSize() * 0.1));
    double cpuPopulationLost = (randomCPUsize -(randomCPUsize * 0.1));
    
      
      
      if (playerChoice ==1 & totalbeePlayerNector3 > totalCPUbfPlayerNector3) {
         System.out.println();
         System.out.println("THE WINNER IS THE BEES!!!!!");
         System.out.print("Bees' size gets tripled: ");
         System.out.println((int)Math.pow(beesInfo.getbeeSize(),3));
         System.out.print("Butterflies' lose a portion of their population: ");
         System.out.println(cpuPopulationLost);
     }   
      
       if (playerChoice ==1 & totalbeePlayerNector3 < totalCPUbfPlayerNector3){
         System.out.println();
         System.out.println("THE WINNER IS THE BUTTERFLIES!!!!!");
         System.out.print("Butterflies' size gets tripled: ");
         System.out.println((int)Math.pow(randomCPUsize,3));
         System.out.print("Bees' lose a portion of their population: ");
         System.out.println(beepopulationLost);
       }
            
       if (playerChoice ==2 & totalbfPlayerNector3 > totalCPUbeePlayerNector3){
          System.out.println();
          System.out.println("THE WINNER IS THE BUTTERFLIES!!!!!");
          System.out.print("Butterflies' size gets tripled: ");    
          System.out.println((int)Math.pow(bfInfo.getbfSize(),3));
          System.out.print("Bees' lose a portion of their population: ");
          System.out.println(cpuPopulationLost);
       }
       
       if (playerChoice ==2 & totalbfPlayerNector3 < totalCPUbeePlayerNector3){
         System.out.println();
         System.out.println("THE WINNER IS THE BEES!!!!!");
         System.out.print("Bees' size gets tripled: ");
         System.out.println((int)Math.pow(randomCPUsize,3));
         System.out.print("Butterflies' lose a portion of their population: ");
         System.out.println(bfpopulationLost);
       }
      
      if (playerChoice ==1 & totalbeePlayerNector3 > totalCPUbfPlayerNector3){
     JFrame frame = new JFrame();
     JOptionPane.showMessageDialog(frame, beesInfo.getbeeName() + " Win!");
     JOptionPane.showMessageDialog(frame, "Congradulations " + playerInfo.getplayerName() );
     JOptionPane.showMessageDialog(frame, "Bees started with: " + beesInfo.getbeeSize());
     JOptionPane.showMessageDialog(frame, "Bees total carry capacity: " + playerCapacity + playerCapacity2 + playerCapacity3);
     JOptionPane.showMessageDialog(frame, "Bees total Distance: " + numMiles + numMiles2 + numMiles3);
     JOptionPane.showMessageDialog(frame, "Bees collected: " + totalbeePlayerNector3);
     JOptionPane.showMessageDialog(frame, "Ending Size: " + (int)Math.pow(beesInfo.getbeeSize(),3));
     JOptionPane.showMessageDialog(frame, "Butterflies started with: " + randomCPUsize);
     JOptionPane.showMessageDialog(frame, "Butterflies total carry capacity: " + player2Capacity + player2Capacity2 + player2Capacity3);
     JOptionPane.showMessageDialog(frame, "Butterflies total Distance: " + numMiles + numMiles2 + numMiles3);
     JOptionPane.showMessageDialog(frame, "Butterflies collected: " + totalCPUbfPlayerNector3);
     JOptionPane.showMessageDialog(frame, "Ending Size: " + cpuPopulationLost);
      }
      
     if (playerChoice ==1 & totalbeePlayerNector3 < totalCPUbfPlayerNector3){
     JFrame frame = new JFrame();
     JOptionPane.showMessageDialog(frame, beesInfo.getbeeName() + " Lose.");
     JOptionPane.showMessageDialog(frame, "Sorry " + playerInfo.getplayerName() );
     JOptionPane.showMessageDialog(frame, "Bees started with: " + beesInfo.getbeeSize());
     JOptionPane.showMessageDialog(frame, "Bees total carry capacity: " + playerCapacity + playerCapacity2 + playerCapacity3);
     JOptionPane.showMessageDialog(frame, "Bees total Distance: " + numMiles + numMiles2 + numMiles3);
     JOptionPane.showMessageDialog(frame, "Bees collected: " + totalbeePlayerNector3);
     JOptionPane.showMessageDialog(frame, "Ending Size: " + beepopulationLost);
     JOptionPane.showMessageDialog(frame, "Butterflies started with: " + randomCPUsize);
     JOptionPane.showMessageDialog(frame, "Butterflies total carry capacity: " + player2Capacity + player2Capacity2 + player2Capacity3);
     JOptionPane.showMessageDialog(frame, "Butterflies total Distance: " + numMiles + numMiles2 + numMiles3);
     JOptionPane.showMessageDialog(frame, "Butterflies collected: " + totalCPUbfPlayerNector3);
     JOptionPane.showMessageDialog(frame, "Ending Size: " + (int)Math.pow(randomCPUsize,3));
      } 
     
     if (playerChoice ==2 & totalbfPlayerNector3 > totalCPUbeePlayerNector3){
     JFrame frame = new JFrame();
     JOptionPane.showMessageDialog(frame,bfInfo.getbfColor() + bfInfo.getbfName() + " Win!");
     JOptionPane.showMessageDialog(frame, "Congradulations " + playerInfo.getplayerName() );
     JOptionPane.showMessageDialog(frame, "Bees started with: " + randomCPUsize);
     JOptionPane.showMessageDialog(frame, "Bees total carry capacity: " + playerCapacity + playerCapacity2 + playerCapacity3);
     JOptionPane.showMessageDialog(frame, "Bees total Distance: " + numMiles + numMiles2 + numMiles3);
     JOptionPane.showMessageDialog(frame, "Bees collected: " + totalCPUbeePlayerNector3);
     JOptionPane.showMessageDialog(frame, "Ending Size: " + cpuPopulationLost);
     JOptionPane.showMessageDialog(frame, "Butterflies started with: " + bfInfo.getbfSize());
     JOptionPane.showMessageDialog(frame, "Butterflies total carry capacity: " + player2Capacity + player2Capacity2 + player2Capacity3);
     JOptionPane.showMessageDialog(frame, "Butterflies total Distance: " + numMiles + numMiles2 + numMiles3);
     JOptionPane.showMessageDialog(frame, "Butterflies collected: " + totalbfPlayerNector3);
     JOptionPane.showMessageDialog(frame, "Ending Size: " + (int)Math.pow(bfInfo.getbfSize(),3));
      }
     
      
     if (playerChoice ==2 & totalbfPlayerNector3 < totalCPUbeePlayerNector3){
     JFrame frame = new JFrame();
     JOptionPane.showMessageDialog(frame, bfInfo.getbfColor() + bfInfo.getbfName() + " Lose.");
     JOptionPane.showMessageDialog(frame, "Sorry " + playerInfo.getplayerName() );
     JOptionPane.showMessageDialog(frame, "Bees started with: " + randomCPUsize);
     JOptionPane.showMessageDialog(frame, "Bees total carry capacity: " + playerCapacity + playerCapacity2 + playerCapacity3);
     JOptionPane.showMessageDialog(frame, "Bees total Distance: " + numMiles + numMiles2 + numMiles3);
     JOptionPane.showMessageDialog(frame, "Bees collected: " + totalCPUbeePlayerNector3);
     JOptionPane.showMessageDialog(frame, "Ending Size: " +  (int)Math.pow(randomCPUsize,3));
     JOptionPane.showMessageDialog(frame, "Butterflies started with: " + bfInfo.getbfSize());
     JOptionPane.showMessageDialog(frame, "Butterflies total carry capacity: " + player2Capacity + player2Capacity2 + player2Capacity3);
     JOptionPane.showMessageDialog(frame, "Butterflies total Distance: " + numMiles + numMiles2 + numMiles3);
     JOptionPane.showMessageDialog(frame, "Butterflies collected: " + totalbfPlayerNector3);
     JOptionPane.showMessageDialog(frame, "Ending Size: " + bfpopulationLost);
      }
}
}

        
      
      
      
      
      
      
     

       
       
      
        
        
        
        
        
        
        
        
    

