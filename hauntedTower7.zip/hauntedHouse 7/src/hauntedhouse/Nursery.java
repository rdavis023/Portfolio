
package hauntedhouse;

import javax.swing.ImageIcon;

import javax.swing.JOptionPane;


public class Nursery {//This is the class for the third level. It has calls
    //the nursery room selection method as well as the guest bedroom method. 
    
    String floorChoice;

    
GuestBedroom guest = new GuestBedroom();// creates object guest of class
//GuestBedroom to use the methods in that class
    
    public void floorSelection(){

    floorChoice = JOptionPane.showInputDialog(null, 
            "You are now on the 3rd floor. You"
            + " see two doors." + "\n"+ "One leads to the \"Nursery\" and the "
            + "other to the \"Guest bedroom\". Which do you choose?");
    
    if (floorChoice.equals("Nursery")){
        guest.nurserySelection();
        
    }
    else if (floorChoice.equals("Guest bedroom")){
        guest.guestSelection();
    }
    else {//Message for invalid inputs
        JOptionPane.showMessageDialog(null, "Sorry! Not a valid input" );   
}
    }
}