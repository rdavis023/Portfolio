/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package monstertester;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;






/**
 *Rahshann Davis 01/22/2023
 * Netbeans IDE 15
 * Java 8.0.0
 * This program includes two classes a Monster and MonsterTester class. The monster
 * class is setup with constructors, getters and setter methods to store and create
 * a monster. The monstertester class is setup to utilze the methods in the monster
 * class to input monster attributes of each individual monster while allowing the
 * user to create his/her own monster.
 */
public class MonsterTester {
  
    public static void Menu(){ //This is the Method for the monster Menu
        System.out.println("         MENU");
                    System.out.println("Which Monster would you like to choose? "
                            + "0-9." + "\n" + "Press 10 to customize your "
                            + "own monster.");
                    System.out.println("Warewolf - 0" + "\n" + "Vampire - 1" + 
                            "\n" + "Banshee - 2" + "\n" + "Zombie - 3" + "\n" + 
                            "Hydra - 4" + "\n" + "Dragon - 5" + "\n" + 
                            "Cyclops - 6" + "\n" + "Gnome - 7" + "\n" + 
                            "Sprite - 8" + "\n" + "Golem - 9" + "\n" + 
                            "Custom monster - 10" + "\n" + "Press 12 to exit.");
                    
    }
    
    public static void Monster(){ //Method that includes scanner method and if 
                                  //statements and the for loop that creates and 
                                  //stores the monster
         Object [] choice3 = {"11- Menu", "12- Keep monster"};// just added array
                                                              //for style
        
        
         Scanner scnr = new Scanner(System.in);//scanner object for user input
          
        //Default monsters stored within monster object to be initialized through
        //constructor lines 47-75
        Monster m1 = new Monster("Beast","Medium","Warewolf",
                "Killer Bite",85,90);
        
        Monster m2 = new Monster("Immortal","Medium","Vampire",
                "Blood Lust",75,80);
        
        Monster m3 = new Monster("Spirit","Small","Banshee",
        "Death Scream",50,40);
        
        Monster m4 = new Monster("Undead", "Medium","Zombie",
        "Brain absorption",25,30);
        
        Monster m5 = new Monster("Beast","Large","Hydra",
        "Cut off one Head, Two more replace it",95,100);
        
        Monster m6 = new Monster("Winged Beast", "Large", "Dragon",
        "Fire Breath",100,95);
        
        Monster m7 = new Monster("Giant", "Large", "Cyclops",
        "Rampage", 80,65);
        
        Monster m8 = new Monster("Fairy","Small","Gnome",
        "Hole digging and Camo",10,60);
        
        Monster m9 = new Monster("Fairy","Small","Sprite",
        "Powerful Magic",60,40);
        
        Monster m10 = new Monster("Rock","Medium","Golem",
        "Impenerable skin",60,90);
        
        
        ArrayList <Monster> monsters2 = new ArrayList();//ArrayList Method created
                                                        //to store object monsters
        monsters2.add(m1);
        monsters2.add(m2);
        monsters2.add(m3);
        monsters2.add(m4);
        monsters2.add(m5);
        monsters2.add(m6);
        monsters2.add(m7);
        monsters2.add(m8);
        monsters2.add(m9);
        monsters2.add(m10);
        
       
        Monster userMonster = new Monster();//object created to store custom monster
        MonsterTester.Menu();//calling monster menu
            
          
           for(int i = 0; i<= monsters2.size(); i++){//for loop used to allow going
                                                     //through array and menu
       
                int userChoice2 = scnr.nextInt();
                scnr.nextLine();
               
               
                if(userChoice2 < 10){//if statement choosing monster
                    
                    System.out.println("Your monsters stats are: ");
                    System.out.println();
                    System.out.println(monsters2.get(userChoice2).toString());
                    System.out.println();
                    System.out.println("Would you like to keep this monster "
                        +  "or go back to menu?" + "\n" + 
                            Arrays.toString(choice3));
                    
                    }
                
                    if(userChoice2 == 10){//if statement creating custom monster
                        System.out.println();
                    
                        System.out.println("Enter monster name: ");
                        String monsterName2 = scnr.nextLine();
                        userMonster.setMonsterName(monsterName2);
                        System.out.println();
                    

                        System.out.println("Enter monster type: " );
                        String monsterType = scnr.nextLine();
                        userMonster.setMonsterType(monsterType);
                        System.out.println();
                    
                    
                        System.out.println("Enter monster size: (small, medium, "
                                + "large)");
                        String monsterSize = scnr.nextLine();
                        userMonster.setMonsterSize(monsterSize);
                    
                    
                        System.out.println("Enter monster skill: " );
                        String monsterSkill = scnr.nextLine();
                        userMonster.setMonsterSkill(monsterSkill);
                    
                   
                        System.out.println("Enter monster strength number: ");
                        int monsterStrength = scnr.nextInt();
                        userMonster.setMonsterStrength(monsterStrength);
                    
                    
                        System.out.println("Enter monster defense number: ");
                        int monsterDefense = scnr.nextInt();
                        userMonster.setMonsterDefense(monsterDefense);
                        monsters2.add(10, userMonster);
                        
                    
                        System.out.println("Here is your monster stats: ");
                        System.out.println(monsters2.get(10).toString());
                        System.out.println("Press 12 to keep monster or Press"
                                + " 11 for the menu.");
                        
                    }
                
                else if(userChoice2 == 11){//if statement for menu
                     MonsterTester.Menu();
                }
                
                else if(userChoice2 == 12){//if statement to leave loop
                  return;
                    
                    
                }
                    
            }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         
        MonsterTester.Monster();//Calling for monster
       //I couldn't figure out to implement the monster customization. Looking 
       //forward to the feedback.
    }
        
       
    }


    


