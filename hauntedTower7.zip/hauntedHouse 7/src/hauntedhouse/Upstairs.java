
package hauntedhouse;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

public class Upstairs {//elevator class...I don't know how to change the name
    
//stores user's choice upon reaching Elevator
    
ImageIcon panel = new ImageIcon("Panel.png");
ImageIcon monster = new ImageIcon("myroom.png");
Object[] elevator = {"Basement-0","Front Door + Dining Hall-1","Living Room-2",
                      "Nursery + Guest Bedroom-3","Master Bedroom-4","My Room (DON'T COME HERE!!)-5",
                      "Attic-6"};


MasterBedroom master = new MasterBedroom();//creates object master of class
//MasterBedroom to use methods for the master bedroom

Basement base = new Basement();// creates object base of class
//Basement to use the methods in that class

Nursery floor = new Nursery();// creates object floor of class Nursery to use 
//methods for both nursery selection and guest selection.

Rooms newRoom = new Rooms();//Creates object newRoom of class Rooms to call
//the methods for the first floor. 
   
Attic attic = new Attic();//Creates object attic of class Attic to call
//the methods for this level.  


public void elevatorSelection(){//this methods calls all the other methods 
        //to get to all the levels in the house.

   
      String elevatorChoice = (String) JOptionPane.showInputDialog(null,"You enter the elevator and notice"
            + " the elevator panel to your left. Which level do you pick?",
            "Elevator", JOptionPane.INFORMATION_MESSAGE, panel,elevator,"Basement-0");
    
    
   
    
    switch(elevatorChoice){
        case "Basement-0":
            base.basementSelection();
            break;
        case "Front Door + Dining Hall-1":
            newRoom.hallwaySelection();
            break;
        case "Living Room-2":
            newRoom.livingRoomSelection();
            break;
        case "Nursery + Guest Bedroom-3":
            floor.floorSelection();

            break;
        case "Master Bedroom-4":
           master.masterSelection();

            break;
        case "My Room (DON'T COME HERE!!)-5":
            JOptionPane.showMessageDialog(null, "The elevator goes up"
                    + " with a terrifying speed. Then it jolts to a stop."
                    + "\n" + "The lights of the elevator flicker until they "
                    + " turn off completely." + "\n" +
                    "You feel immense dread as the lights turn on one"
                    + " last time. The last thing you remember is turning to"
                    + " see terrifying figure behind you." 
                    + "\n" + "GAME OVER"
                    + "\n" +
                    "Backpack Contents: NONE", "Monster", 
                    JOptionPane.INFORMATION_MESSAGE, monster);
            break;
        case "Attic-6":
            attic.atticSelection();
            break;
        default:
             JOptionPane.showMessageDialog(null, "Not a valid input" );   

            
    } 
   
    
} 
}
    
    

