
package hauntedhouse;

//*****************************************************************************
// PantherID:  6380004
// CLASS: COP 2210 – [Fall Semester 2022]
// ASSIGNMENT # [3]
// DATE: [11/2/2022]
//
// I hereby swear and affirm that this work is solely my own, and not the work
// or the derivative of the work of someone else.
//*****************************************************************************

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
public class HauntedHouse {//main class

    public static void main(String[] args) {
        
           String userName;//Stores user's name in this string.
           String firstChoice;//Stores user's first choice in this string.    
        
           ImageIcon house = new ImageIcon("Haunted.jpg");
           ImageIcon door = new ImageIcon("door.png");

    Rooms newRoom = new Rooms();//Creates object newRoom of class Rooms to call
             //the methods for the first floor.
    Upstairs elevator = new Upstairs();//Creates object elevator of class
    //Upstairs to call the methods for the elevator.
    
    
       userName = JOptionPane.showInputDialog("You have dared to enter"
                + " the tower of ghouls and goblins!" + "\n" 
                + "Enter your user name:");
    
    JOptionPane.showMessageDialog(null, "Welcome " + userName + "!" ,
            "Haunted", 
            JOptionPane.INFORMATION_MESSAGE, house );
   
    JOptionPane.showMessageDialog(null, "You enter through the front door."
            + " The door locks"
                + " behind you. You won't be able to leave without the"
                + " key to the front door." + "\n"
            + " You have no choice but to search for it.", "Door",
                JOptionPane.INFORMATION_MESSAGE, door);        
        
    
   
    firstChoice = JOptionPane.showInputDialog(null, "Decide what"
                + " to explore next:" + " \n" + 
                "\"Hallway\" or \"Elevator\" or \"Exit\"?");
        
   
    if (firstChoice.equals("Hallway")) {
        
        newRoom.hallwaySelection();//call hallway selection method
     }

    else if (firstChoice.equals("Elevator")){
   
            elevator.elevatorSelection();//call elevator selection method
}
    else if(firstChoice.equals("Exit")){
        JOptionPane.showMessageDialog(null, "Sorry, " + userName +
                "! You need the front door key to leave. Keep looking for it!");
        //FIX ME  add condition for front door key to leave the tower.
    }
    else {//Message for invalid inputs
        JOptionPane.showMessageDialog(null, "Sorry," + userName +
                "! Not a valid input" );   
}
}
    }


