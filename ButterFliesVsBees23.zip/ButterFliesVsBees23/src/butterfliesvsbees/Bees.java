/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package butterfliesvsbees;

/**
 *
 * @author Rahshann
 */
import java.util.Random;

/**
 *
 * @author Rahshann
 */
public class Bees {
    private String beeName;
    private int beeSize;
    private int beeCapacity;
    
    
    public Bees() {
         Random randomNum = new Random();
         beeSize = 1 + randomNum.nextInt(10);

    }
    
    public void setbeeName(String beeName){
        this.beeName = beeName;
    }
    
    public void setbeeSize(int beeSize){
        this.beeSize = beeSize;
    }
        
    public void setbeeCapacity(int beeCapacity){
        this.beeCapacity = beeCapacity;
    }
    
    public Bees(int size, int capacity) {
        this.beeSize = size;
        this.beeCapacity = capacity;
    }

    public Bees(String beeName, int beeSize) {
        this.beeName = beeName;
        this.beeSize = beeSize;
        
    }
    
    public String getbeeName() {
        return beeName;
    }

    public int getbeeSize() {
        return beeSize;
    }

    public int beeCapacity() {
        return beeCapacity;
    }
    
  public void printInfo() {
      Random capacity = new Random();
      
      for(int counter=1; counter<=1;counter++){
            beeCapacity = 1 + capacity.nextInt(8);
        }
        
    
        System.out.println("capacity: " + beeCapacity + " grams");
}
}

