
package hauntedhouse;


import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

public class Attic {
    String atticChoice;//stores user's choice upon entering attic. 
    
    
    ImageIcon attic = new ImageIcon("Attic.jpg");
    ImageIcon key = new ImageIcon("Key.png");
    ImageIcon snake = new ImageIcon("snake.jpg");

    public void atticSelection(){
        

        // FIX ME:: must add if else statement for attic key
        
        
        
       JOptionPane.showMessageDialog(null, "Finally,"
               + " you have reached the attic, which is the "
               + "highest floor of the tower.", "Attic",
               JOptionPane.INFORMATION_MESSAGE, attic); 
       atticChoice = JOptionPane.showInputDialog(null,
                 "You can either open an old \"chest\" or look behind a "
               + "\"curtain\". Which do you choose?");
       
       if (atticChoice.equals("chest")){
           JOptionPane.showMessageDialog(null, "You open the chest and find "
                   + "another key. You put it in your backpack."
                   + "\n"+ "Backpack Contents: Front door key", "Key",
               JOptionPane.INFORMATION_MESSAGE, key); 
           
       }
       
       else if (atticChoice.equals("curtain")){
            JOptionPane.showMessageDialog(null, "As you move the soft fabric,"
                    + " you hear a hissing sound. You look down to see a "
                    + "snake slithering near your feet." + "\n"
                    + " You try to run away"
                    + " but it is too late."
                +"\n"+ "GAME OVER" + "\n "+ "Backpack Contents: NONE",
                        "Curtain", JOptionPane.INFORMATION_MESSAGE, snake);
       }
      
        else {//Message for invalid inputs
        JOptionPane.showMessageDialog(null, "Sorry! Not a valid input" );   
    }
    
    }
}