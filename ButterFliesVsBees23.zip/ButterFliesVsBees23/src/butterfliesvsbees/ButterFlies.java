/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package butterfliesvsbees;

/**
 *
 * @author Rahshann
 */
import java.util.Random;

/**
 *
 * @author Rahshann
 */
public class ButterFlies {
    private String bfName;
    private String bfColor;
    private int bfSize;
    private int bfCapacity;

    public ButterFlies() {
        bfCapacity = 0;
    }
    
    public void setbfName(String bfName) {
        this.bfName = bfName;
    }
    
    public void setbfColor(String bfColor) {
        this.bfColor = bfColor;
    }
    
    public void setbfSize(int bfSize) {
        this.bfSize = bfSize;
    }
    public void setbfCapacity(int bfCapacity){
        Random capacity = new Random();
        for(int counter=1; counter<=1;counter++){
            bfCapacity = 1 + capacity.nextInt(10);
        }
    }
    
    public ButterFlies(String bfName, int capacity) {
        this.bfName = bfName;
        this.bfCapacity = capacity;
    }

    public ButterFlies(String bfName, String bfColor, int bfSize) {
        this.bfName = bfName;
        this.bfColor = bfColor;
        this.bfSize = bfSize;
       
    }
    
    public String getbfName() {
        return bfName;
    }

    public String getbfColor() {
        return bfColor;
    }

    public int getbfSize() {
        return bfSize;
    }

    public int bfCapacity() {
        return bfCapacity;
    }
    
  public void printInfo() {
      Random capacity = new Random();
      
        for(int counter=1; counter<=1;counter++){
            bfCapacity = 1 + capacity.nextInt(10);
        }
        
        System.out.println("capacity: " + bfCapacity + " grams");
      
      
      
      
  }
}

