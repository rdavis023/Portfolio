
package hauntedhouse;

import javax.swing.JOptionPane;
import javax.swing.ImageIcon;


public class MasterBedroom {

String mBedroomChoice; //stores user's choice upon entering master bedroom
String mBathroomChoice;//stores user's choice upon entering master bathroom

ImageIcon master = new ImageIcon("Master.png");
ImageIcon jewelry = new ImageIcon("Jewelry.gif");
ImageIcon bathroom = new ImageIcon("Bathroom.jpg");

public void masterSelection(){//method for master bedroom selection
    
    JOptionPane.showMessageDialog(null, "As you enter the"
                + " master bedroom, you are shocked to see a large crystyal"
                + " jewelry box." + "\n" + "Its beauty is breaktaking. You also"
                + " notice a door leading to the master bathroom.", "Master "
                        + "Bedroom",
                JOptionPane.INFORMATION_MESSAGE, master);
    mBedroomChoice = JOptionPane.showInputDialog(null, "Do you"
                + " explore the \"Jewelry box\" or \"Enter bathroom\"?"
    + " You can also return to the \"Elevator\".");
                if (mBedroomChoice.equals("Jewelry box")) {
                     JOptionPane.showMessageDialog(null, "The jewelry box opens"
                             + " and the eerie tune that begins to play gets"
                             + " louder and louder. " + "\n" + "You shut the "
                             + "box"
                             + " trying to get rid of the sound but the"
                             + " shrieking "
                             + "gets louder until its ringing pierces your "
                             + "eardrums." + "\n" + "GAME OVER"
                             + "\n" + "Backpack Contents: NONE",
                             "Jewelry Box",
                             JOptionPane.INFORMATION_MESSAGE, jewelry);
                }
                else if (mBedroomChoice.equals("Enter bathroom")){
                    mBathroomChoice = JOptionPane.showInputDialog(null, 
                            "Inside the bathroom, there is a sink and a box of "
                                    + "essential oils. Do you want to explore "
                                    + "the \"Sink\" or the \"Box\"?"); 
                        if(mBathroomChoice.equals("Sink")) {
                            JOptionPane.showMessageDialog(null, "You turn on "
                                    + "the faucet to wash the dust off your "
                                    + "hands." + "\n" + "A red trickle lands on"
                                    + " your hands. You draw your hands back in"
                                    + " horror as you realize the faucet is"
                                    + " leaking blood, not water." + "\n" + 
                                    "You grab a towel and run out of the "
                                    + "house" + "\n" + "THE END"
                                    + "\n" + "Backpack Contents: Towel",
                                    "Bathroom",
                                    JOptionPane.INFORMATION_MESSAGE, bathroom);
                            
                        }
                        else if(mBathroomChoice.equals("Box")) {
                            JOptionPane.showMessageDialog(null, "The oils have "
                                    + "a beautiful smell. You apply some on "
                                    + "your"
                                    + " wrists." + "\n" + "The smell goes "
                                    + "from pleasant to nasueating in seconds. "
                                    + "\n" + 
                                    "You feel suffocated by the smell and"
                                 + " begin to choke. " + "\n" + 
                                    "The room goes dark and "
                                    + "you fall on the bathroom floor."+ "\n" +
                                    "GAME OVER"
                                    + "\n" + "Backpack Contents: NONE",
                                     "Bathroom",
                                    JOptionPane.INFORMATION_MESSAGE, bathroom);
                        }
                          else {//Message for invalid inputs
        JOptionPane.showMessageDialog(null, "Sorry! Not a valid input" );   
}
                }
                
               
                
                
                  else {//Message for invalid inputs
        JOptionPane.showMessageDialog(null, "Sorry! Not a valid input" );   
}
}

}
