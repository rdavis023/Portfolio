
package hauntedhouse;

import javax.swing.JOptionPane;
import javax.swing.ImageIcon;



public class Basement {
    
 String basementChoice;

ImageIcon basement = new ImageIcon("basement.jpg");
ImageIcon boiler = new ImageIcon("boiler.jpg");
ImageIcon storage = new ImageIcon("storage.png");


    public void basementSelection(){

  JOptionPane.showMessageDialog(null, "The elevator doors slide open."
          + " You are now in the basement.", 
                "Basement", JOptionPane.INFORMATION_MESSAGE, basement);
              basementChoice = JOptionPane.showInputDialog(null, "In the "
                        + "basement, you see two doors. One leads to the "
                        + "\"Boiler Room\"."
                      + "\n" + "The other leads to the \"Storage\"."
                      + "You can also return to the \"Elevator\"."
                        
                        + "Which do you choose?"); 
              
            if (basementChoice.equals("Boiler Room")){
                JOptionPane.showMessageDialog(null, "Upon entering the boiler"
                        + " room, you hear loud clanking and whooshing." + "\n"+
                        "You turn around to leave but the room door is locked "
                        + "behind you." + "\n"+ "The room begins to fill "
                        + "with toxic fumes. You feel suffocated and fall to "
                        + "the ground, unconscious."
                +"\n"+ "GAME OVER" + "\n "+ "Backpack Contents: NONE",
                        "Boiler Room", JOptionPane.INFORMATION_MESSAGE, boiler);
            }
            else if (basementChoice.equals("Storage")){
                JOptionPane.showMessageDialog(null, "You enter the storage room"
                        + " and open a closet in front of you." + "\n"
                        + "You notice a key at the bottom of the closet."
                        + " You place it in your backpack and leave the room."
                        + "\n "+ "Backpack Contents: Attic Key",
                        "Closet", JOptionPane.INFORMATION_MESSAGE, storage);
                
            }
       
            
            
             else {//Message for invalid inputs
        JOptionPane.showMessageDialog(null, "Sorry! Not a valid input" );   
}
    
    }
    
}
