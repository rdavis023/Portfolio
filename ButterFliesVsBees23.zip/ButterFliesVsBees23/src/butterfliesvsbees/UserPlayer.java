/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package butterfliesvsbees;

/**
 *
 * @author Rahshann
 */
public class UserPlayer {
    private String playerName;
    private final String compUser;
    private String playerChoice;
    private String flowerType;
    private String flowerColor;
    private String flowerType2;
    private String flowerColor2;
    private String flowerType3;
    private String flowerColor3;
   
    
    
    public UserPlayer(){
        this.compUser = "Mr. Computer";
             
    }
    
    public void setflowerType(String flowerType){
        this.flowerType = flowerType;
    }
    
    public void setflowerColor(String flowerColor){
        this.flowerColor = flowerColor;
    }
    
    public void setflowerType2(String flowerType2){
        this.flowerType2 = flowerType2;
    }
    
    public void setflowerColor2(String flowerColor2){
        this.flowerColor2 = flowerColor2;
    }
    
    public void setflowerType3(String flowerType3){
        this.flowerType3 = flowerType3;
    }
    
    public void setflowerColor3(String flowerColor3){
        this.flowerColor3 = flowerColor3;
    }
    
    public void setplayerName(String playerName) {
        this.playerName = playerName;
    }
    
    public void setplayerChoice(String playerChoice) {
        this.playerChoice = playerChoice;
    }
    
    public String getflowerType(){
        return flowerType;
    }
    
    public String getflowerColor(){
        return flowerColor;
    }
    
    public String getflowerType2(){
        return flowerType2;
    }
    
    public String getflowerType3(){
        return flowerType3;
    }
    
    public String getflowerColor2(){
        return flowerColor2;
    }
    
    public String getflowerColor3(){
        return flowerColor3;
    }
    
    public String getplayerChoice() {
        return playerChoice;
    }
    
    public String getplayerName() {
        return playerName;
    }
    
    public String getcompUser() {
        return compUser;
    }
    
  
  }  
  

