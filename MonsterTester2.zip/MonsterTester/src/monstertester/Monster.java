/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package monstertester;



/**
 *
 * @author Rahshann
 */
public final class Monster {
    
    private String monsterType;
    private String monsterSize;
    private String monsterName;
    private String monsterSkill;
    private int monsterStrength;
    private int monsterDefense;
    private Monster monster;
    
   
    
 
   
   public Monster(){// the default constructor
       monsterType = "Type";
       monsterSize = "Size";
       monsterName = "Name";
       monsterSkill = "Skill";
       monsterStrength = 100;
       monsterDefense = 100;
   }
    
    public Monster(String type, String size, String name, String skill, int
            strength, int defense){//Constructor for default monsters
        
        monsterType = type;
        monsterSize = size;
        monsterName = name;
        monsterSkill = skill;
        monsterStrength = strength;
        monsterDefense = defense;   
    }
    
    @Override
    public String toString(){//toString override allowing the return of Monster stats as String
        return "Monster Name: " + monsterName + "\n" + "Monster Type: " + 
                monsterType + "\n" + "Monster Size: " + monsterSize + "\n" +
                "Monster Skill: " + monsterSkill + "\n" + "Monster Strength: " +
                monsterStrength + "\n" + "Monster Defense: " + monsterDefense;
    }
    
    //Getter and Setter Methods for storing and getting custom monster lines 56-126
    public void setMonsterType(String type){
         monsterType = type;
       }
    
    public String getMonsterType(){
        return monsterType;
    }
    
    public void setMonsterSize(String size){
        monsterSize = size;
       
    }
    
    public String getMonsterSize(){
        return monsterSize;
    }
    
    public void setMonsterName(String name){
        monsterName = name;
    }
    
    public String getMonsterName(){
        return monsterName;
    }
    
    public void setMonsterSkill(String skill){
        monsterSkill = skill;
    }
    
    public String getMonsterSkill(){
        return monsterSkill;
    }
    
    public void setMonsterStrength(int strength){
       if(monsterSize.equalsIgnoreCase("small")){
           monsterStrength = strength - 50;
        }
       
       else if(monsterSize.equalsIgnoreCase("medium")){
           monsterStrength = strength + 10;
       }
       
       else {
           monsterStrength = strength + 20;
       }
        
       
        
    }
    
    public int getMonsterStrength(){
        return monsterStrength;
    }
    
    public void setMonsterDefense(int defense){
         if(monsterSize.equalsIgnoreCase("small")){
           monsterDefense = defense - 50;
        }
       
       else if(monsterSize.equalsIgnoreCase("medium")){
           monsterDefense = defense + 10;
       }
       
       else {
           monsterDefense = defense + 50;
       }
    }
    
    public int getMonsterDefense(){
        return monsterDefense;
    }
    
  
}


