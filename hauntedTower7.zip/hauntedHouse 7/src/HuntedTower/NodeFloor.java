package HuntedTower;

public class NodeFloor {

    public int FloorNum;
    public String name;
    public NodeFloor next;
    public Rooms[] listOfRooms;

    public NodeFloor(int floorNum, Rooms[] listOfRooms) {
        FloorNum = floorNum;
        this.name = null;
        this.next = null;
        this.listOfRooms = listOfRooms;
    }

    public NodeFloor(int floorNum, String name) {
        FloorNum = floorNum;
        this.name = name;
        this.next = null;
    }

    public NodeFloor(int floorNum, String name, NodeFloor next, Rooms[] listOfRooms) {
        FloorNum = floorNum;
        this.name = name;
        this.next = next;
        this.listOfRooms = listOfRooms;
    }

    public void roomSelection(){
        int index = 1;
        for (Rooms r: listOfRooms){
            System.out.println("Please select "+index+" to enter: " + r.name);
            index++;
        }
    }
    public void displayRoom(int index){
        listOfRooms[index - 1].roomInfo();
    }
}
