package HuntedTower;

public class Rooms {
    public String name;
    public String[] item;
    public String outcome;

    public Rooms(String name, String[] item, String outcome) {
        this.name = name;
        this.item = item;
        this.outcome = outcome;
    }

    public void roomInfo(){
        System.out.println("You have entered: " +this.name);
        itemSelection();
    }

    public void itemSelection(){
        int index = 1;
        for(String x: item){
            System.out.println("Please select "+index+" to enter: " + x);
            index++;
        }
    }
    public String displayItem(int index){
        System.out.println("You have chosen the following item: " + item[index - 1]);
        return item[index - 1];
    }
}
