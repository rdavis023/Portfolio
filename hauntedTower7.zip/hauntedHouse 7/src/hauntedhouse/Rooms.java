
package hauntedhouse;

import javax.swing.JOptionPane;
import javax.swing.ImageIcon;


public class Rooms {//this class contains two methods: one for the living room
    //selection and one for the hallway selection. 
    
    String firstChoiceA;//stores user's choice upon entering living room
    String bathroomChoice;//stores user's choice upon entering bathroom
    String firstChoiceB;//stores user's choice upon entering hallway
    String kitchenChoice;//stores user's choice upon entering kitchen
    String pantryChoice;//stores user's choice upon opening pantry
    
    
    ImageIcon hallway = new ImageIcon("Hallway.jpg");
    ImageIcon fire = new ImageIcon("Fire.png");
    ImageIcon kitchen = new ImageIcon("kitchen.png");
    ImageIcon shower = new ImageIcon("Shower.png");
    ImageIcon treasure = new ImageIcon("treasure.jpg");
    ImageIcon gold = new ImageIcon("gold.jpg");
    ImageIcon spider = new ImageIcon("Spider.jpg");
    ImageIcon living = new ImageIcon("Living.jpg");
    ImageIcon mirror = new ImageIcon("Mirror.jpg");
    ImageIcon dining = new ImageIcon("Dining.jpg");

    public void livingRoomSelection(){//this method contains all options after
        //user chooses to enter living room
        
        JOptionPane.showMessageDialog(null, "You enter the living room.",
                "Living room", JOptionPane.INFORMATION_MESSAGE, living);
        
      firstChoiceA = JOptionPane.showInputDialog(null, "You have two options:"
              + " \"Enter bathroom\" "
                + "or \"Explore treasure chest\" in the living room.");
                
        
                if (firstChoiceA.equals("Explore treasure chest")) {
                    JOptionPane.showMessageDialog(null, "Two hands pull you "
                            + "deep into the treasure chest and you fall "
                            + "down through a bottomless pit to your"
                            + " doom." + "\n"+" GAME OVER"
                            + "\n" + "Backpack Contents: NONE",

                            "Treasure Chest",
                            JOptionPane.INFORMATION_MESSAGE,
                            treasure);
                }
                else if (firstChoiceA.equals("Enter bathroom")){
                    
                    
                    JOptionPane.showMessageDialog(null, "The bathroom door "
                            + "creaks open.", 
                            "Shower",
                                      JOptionPane.INFORMATION_MESSAGE, shower);
                    bathroomChoice = JOptionPane.showInputDialog(null, 
                            "You see a \"Mirror\" "
                            + "and "
                            + "a \"Shower\". Which do you want to explore?");
                
                            if (bathroomChoice.equals("Mirror")){
                            JOptionPane.showMessageDialog(null, "You see"
                                    + " a shadow move behind you. You turn "
                                    + "around and see a terrfiying witch! "
                                    + "One look into her deadly eyes and you "
                                    + "freeze to death." + "\n" + "GAME OVER"
                                    + "\n" + "Backpack Contents: NONE",

                                    "Mirror", JOptionPane.INFORMATION_MESSAGE,
                                            mirror);
                }
                            else if(bathroomChoice.equals("Shower")){
                                    JOptionPane.showMessageDialog(null, "You "
                                    + "notice a delicate diamond ring near the"
                                    + " drain. As you scoop it up into your"
                                    + " backpack, you hear the faint sound of a"
                                    + " child singing." + "\n" + "You pocket"
                                            + " the ring and "
                                    + "run out of the house." + "\n" +
                                      "  THE END."
                                    + "\n" + "Backpack Contents: Ring",

                                            "Shower",
                                      JOptionPane.INFORMATION_MESSAGE, shower);
                                    
                                    }
                            
                          else {//Message for invalid inputs
        JOptionPane.showMessageDialog(null, "Sorry! Not a valid input" );   
}
                                    } 
                  else {//Message for invalid inputs
        JOptionPane.showMessageDialog(null, "Sorry! Not a valid input" );   
}
        
    }
     public void hallwaySelection(){//this method contains all possible options 
        //after user chooses hallway
      
     JOptionPane.showMessageDialog(null, "The floorboards creak beneath"
                + " you as you walk through the hallway into the dining room", 
             "Hallway", 
            JOptionPane.INFORMATION_MESSAGE, hallway);
     JOptionPane.showMessageDialog(null, "You enter the dining room.",
             "Dining Room", JOptionPane.INFORMATION_MESSAGE, dining);
        firstChoiceB = JOptionPane.showInputDialog(null, "You have two options:"
                + " \"Enter kitchen\" "
                + "or \"Explore candelabra\" in the dining room.");
                
        
                if (firstChoiceB.equals("Explore candelabra")) {
                    JOptionPane.showMessageDialog(null, "The candelabra ignites"
                            + " into a six foot high flame. A devilish face "
                            + "appears in the fire and begins to laugh evilly." 
                            +
                            "\n"
                            + "You turn to escape but the fire has surrounded "
                            + "you on all sides. You close your eyes and "
                            + "prepare to die." + "\n" +"GAME OVER"
                            
                             + "\n" + "Backpack Contents: NONE",

                             "Flames",
                             
            JOptionPane.INFORMATION_MESSAGE, fire);
                }
                
                else if (firstChoiceB.equals("Enter kitchen")){
                    
                    JOptionPane.showMessageDialog(null, "You enter the"
                            + " kitchen.", "Kitchen", 
                            JOptionPane.INFORMATION_MESSAGE, kitchen);
                  kitchenChoice = JOptionPane.showInputDialog(null, "You "
                          + "see a \"Fridge\", \"Cabinet\", and a "
                          + "\"Pantry\". Which do you select?");
                           
            
                  
                          if (kitchenChoice.equals("Fridge")){ 
                              JOptionPane.showMessageDialog(null, "The fridge "
                                      + "door opens and you see a single candy "
                                      + "inside. You pocket the candy and run "
                                      + "out of the haunted house." + "\n"
                              + "THE END"
                              + "\n" + "Backpack Contents: Candy",

                                      "Kitchen", 
                            JOptionPane.INFORMATION_MESSAGE, kitchen);
                                     
                            
                          }
                          else if (kitchenChoice.equals("Cabinet")){
                          JOptionPane.showMessageDialog(null, "The cabinet"
                                      + " door is ajar. As you peek inside, all"
                                  + " the cabinet doors in the kitchen begin"
                                  + " to "
                                  + "open and shut violently themselves." + "\n"
                                + "A ghostly woman appears and shrieks \"How "
                                  + "dare you enter MY KITCHEN??!\" You faint"
                                  + " at the sight of her ghastly appearance."
                                  + "\n" +"GAME OVER"
                                  + "\n" + "Backpack Contents: NONE",

                                 
                                  "Kitchen", 
                            JOptionPane.INFORMATION_MESSAGE, kitchen);
                          }
                          
                          else if (kitchenChoice.equals("Pantry")){
                              pantryChoice = JOptionPane.showInputDialog(null, 
                               "You open the pantry to see two cookie jars: One"
                                       + " is \"Red\" and the other is "
                                       + "\"Yellow\"."
                                       + " Which will you open?");
                                       if (pantryChoice.equals("Red")) {
                                        JOptionPane.showMessageDialog(null, 
                                         "You struck gold! A 24 carat gold bar"
                                                 + " lies inside the jar. You "
                                                 + "put it in your backpack and"
                                                 + " run home." +"\n" +
                                                 "THE END"
                                     + "\n" + "Backpack Contents: Gold bar",
                                         "Red Jar", 
                                         JOptionPane.INFORMATION_MESSAGE, gold);

                                                }
                                       else if (pantryChoice.equals("Yellow")){
                                           JOptionPane.showMessageDialog(null,
                                           "Yikes! A giant spider crawls out "
                                                 + "and bites your hand. The"
                                                 + " venom from the spider "
                                                   + "ceases your heart beats"
                                                 + " as darkness envelopes you"
                                                   + "." + "\n" +"GAME OVER"
                                     + "\n" + "Backpack Contents: None", 
                                           "Yellow Jar",
                                           JOptionPane.INFORMATION_MESSAGE, 
                                           spider

                                           );
                                       }
                                       
                             else {//Message for invalid inputs
        JOptionPane.showMessageDialog(null, "Sorry! Not a valid input" );   
}
                  
                          }
                          
                          
                            else {//Message for invalid inputs
        JOptionPane.showMessageDialog(null, "Sorry! Not a valid input" );   
}
                          }
                  else {//Message for invalid inputs
        JOptionPane.showMessageDialog(null, "Sorry! Not a valid input" );   
}
         
         
     }
        
    }
    
    
         
                    
                    
                

