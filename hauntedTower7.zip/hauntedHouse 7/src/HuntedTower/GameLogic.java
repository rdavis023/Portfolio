package HuntedTower;

import java.util.Scanner;

public class GameLogic {

    public static void main(String[] args){

        NodeFloor p0 = new NodeFloor(0, new Rooms[]{new Rooms("Boiler" , null , "Boiler outcome"), new Rooms("Storage" , new String[]{"Attic Key"} , "Storage outcome")});
        NodeFloor p1 = new NodeFloor(1 , new Rooms[]{new Rooms("Exit Door" , null , "Lobby outcome")});
        NodeFloor p2 = new NodeFloor(2, new Rooms[]{new Rooms("Living" , new String[]{"Chest"} , "Living outcome") , new Rooms("Bathroom" , new String[]{"Mirror" , "Shower"}, "Bathroom outcome")});
        NodeFloor p3 = new NodeFloor(3, new Rooms[]{new Rooms("Dining" , new String[]{"Candelabra"} , "Dining outcome")});
        NodeFloor p4 = new NodeFloor(4, new Rooms[]{new Rooms("Kitchen" , new String[]{"Refrigerator" , "Cabinet"} , "Kitchen outcome") , new Rooms("Pantry" , new String[]{"Dusty recipe books" , "Broom"} , "Pantry outcome")});
        NodeFloor p5 = new NodeFloor(5,new Rooms[]{new Rooms("Master Bed" , new String[]{"Jewelry Box"} , "Master Bed outcome") , new Rooms("Master Bath" , new String[]{"Intricate oil lap"} , "Master Bath outcome")});
        NodeFloor p6 = new NodeFloor(6 , new Rooms[]{new Rooms("Guest" , new String[]{"Doll House","Dresser"} , "Guest outcome") , new Rooms("Bathroom" , new String[]{"Mirror" , "Shower"}, "Bathroom outcome")});
        NodeFloor p7 = new NodeFloor(7 , new Rooms[]{new Rooms("Attic" , new String[]{"Front Door Key"} , "Attic outcome")});
        NodeFloor curr = p1;

        StringBuilder bookPack = new StringBuilder();
        boolean hasAtticKey = false;
        boolean hasFrontDoorKey = false;

        p0.next = p1;
        p1.next = p2;
        p2.next = p3;
        p3.next = p4;
        p4.next = p5;
        p5.next = p6;
        p6.next = p7;
        p7.next = null;

        Scanner scan = new Scanner(System.in);
        int userInput;

       try{
           do{
               System.out.println("We are currently in floor " + curr.FloorNum);
               System.out.println("Please choose a floor");
               userInput = scan.nextInt();
               curr = p0;

               while (userInput != curr.FloorNum){
                   curr = curr.next;
               }

               if (curr.FloorNum == 7){
                   if (!hasAtticKey){
                       System.out.println("The attic is locked, please find the key");
                       continue;
                   }
                   else{
                       System.out.println("You have the key, would you like to enter the Attic?");
                   }
               }
               else if(curr.FloorNum == 1){
                   if (!hasFrontDoorKey){
                       System.out.println("The exit door is locked");
                       continue;
                   }
                   else{

                       System.out.println("You have the key to exit! please enter 1 to exit the game");
                       userInput = scan.nextInt();
                       if (userInput == 1){
                           return;
                       }
                   }
               }

               System.out.println("You are in floor " + curr.FloorNum);
               curr.roomSelection();
               userInput = scan.nextInt();
               curr.displayRoom(userInput);
               Rooms currRoom = curr.listOfRooms[userInput-1];
               userInput= scan.nextInt();
               bookPack.append(currRoom.displayItem(userInput) + " , " );
               System.out.println("INVENTORY: " + bookPack);

               if(bookPack.indexOf("Attic Key") != -1 && !hasAtticKey){
                   System.out.println("You have the Attic key, now you can enter floor 7");
                   hasAtticKey = true;
               }

               if(bookPack.indexOf("Front Door Key") != -1 && !hasFrontDoorKey){
                   System.out.println("You have the Key to exit the building, please return to Floor 1 to exit");
                   hasFrontDoorKey = true;
               }



           }while (true);

       }catch (Exception e){
           System.out.println("invalid input please try again");
           main(null);
       }
    }
}
