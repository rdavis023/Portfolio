
package hauntedhouse;

import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

public class SharedBathroom {

    String common;//stores user's choice upon entering common bathroom
    
    ImageIcon bath = new ImageIcon("Bath.png");

    public void commonBathroom(){//This method is for the common bathroom. 
        //This method will be called into the nursery class and the guest class.
        common = JOptionPane.showInputDialog(null, "In this common bathroom"
                + " you can see a \"Bathtub\" and a \"Bathrobe\"." + "\n" + 
                "Which do you explore?");
        
        if (common.equals("Bathtub")){
            JOptionPane.showMessageDialog(null, "The bathtub is filled to the"
                    + " brim"
                    + " with dark murky water. The water swirls and shows a "
                    + "vision of a beautiful baby." + "\n" + "The vision"
                    + " is so realistic, that you reach into the water to pick"
                    + " up the baby." + "\n" + "The vision disappears. The"
                    + " only thing you grab is a baby's rattle. As sounds"
                    + " of a baby crying fill the bathroom, you turn and run"
                    + " out of the house." + "\n" + "THE END"
                    + "\n" + "Backpack Contents: Rattle"
                    , "Bathtub",
                    JOptionPane.INFORMATION_MESSAGE, bath);
        }
        else if (common.equals("Bathrobe")){
            JOptionPane.showMessageDialog(null, "As you touch the bathrobe, "
                    + "a whispy ghost appears next to you and whispers,"
                    + "\n" +
                    "\"You dare to touch my things? Look what happens when"
                    + " I touch you.\"" + "\n" + "As the ghost touches you"
                    + ", you begin to shake incontrollably." + "\n" + "You "
                    + "stare at the ghost who smiles devilishly as you fall to"
                    + " the ground." + "\n" + "GAME OVER"
                    + "\n" + "Backpack Contents: NONE"
                    , "Bathroom",
                    JOptionPane.INFORMATION_MESSAGE, bath);
        
        }
      else {//Message for invalid inputs
        JOptionPane.showMessageDialog(null, "Sorry! Not a valid input" );   
}
    
}
}