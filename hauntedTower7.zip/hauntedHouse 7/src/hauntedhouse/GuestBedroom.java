
package hauntedhouse;

import javax.swing.JOptionPane;
import javax.swing.ImageIcon;


public class GuestBedroom {
    
    SharedBathroom bthrm = new SharedBathroom();//creates object bthrm of class
//Shared Bathroom to call methods from that class
    
        String guestChoice; //stores user's choice upon entering guest room

    
    String nurseryChoice;//stores user's choice upon entering nursery room

        ImageIcon nursery = new ImageIcon("Nursery.jpg");
        ImageIcon chair = new ImageIcon("Chair.png");
        ImageIcon window = new ImageIcon("window.png");

        ImageIcon guest = new ImageIcon("Guest.png");
        ImageIcon bed = new ImageIcon("Bed.png");
        ImageIcon key = new ImageIcon("Key.png");

        
         public void nurserySelection(){//method for nursery room options
        
        JOptionPane.showMessageDialog(null, "You are now in the nursery.", 
                "Nursery", JOptionPane.INFORMATION_MESSAGE, nursery);
              nurseryChoice = JOptionPane.showInputDialog(null, "In the "
                        + "nursery, you see a \"Rocking chair\" and a "
                        + "\"Window\"."
                        + "You also see the entrance to the "
                        + "\"Common bathroom\"."
                        + "\n" + "Which do you choose?"); 
                
                        if (nurseryChoice.equals("Common bathroom")){
                            bthrm.commonBathroom();//calls common bathroom 
                            //selection method
                        }
                        
                        else if (nurseryChoice.equals("Rocking chair")){
                            JOptionPane.showMessageDialog(null, "The chair"
                                    + " is surprisingly comfortable. You rock"
                                    + " back and forth. " + "\n"+ "You realize"
                                    + " you are falling asleep. When you try"
                                    + " to stand up, you are unable to. It hits"
                                    + " you. You are doomed to rock "
                                    + "on the chair"
                                    + " forever." +"\n"+ "GAME OVER"
                                    + "\n" + "Backpack Contents: NONE",
                                    "Rocking Chair", 
                                    JOptionPane.INFORMATION_MESSAGE, chair);
                        }
                        else if (nurseryChoice.equals("Window")){
                            JOptionPane.showMessageDialog(null, "A brooch lies"
                                    + " on the window sill. You put the brooch"
                                    + " in your backpack and run out of the"
                                    + " house." +"\n"+ "THE END"
                                    + "\n" + "Backpack Contents: Brooch",
                                    "Window",
                                    JOptionPane.INFORMATION_MESSAGE, window);}
    
    else {//Message for invalid inputs
        JOptionPane.showMessageDialog(null, "Sorry! Not a valid input" );   
}
         }
    public void guestSelection(){//method for guest bedroom options
        
        
        JOptionPane.showMessageDialog(null, "As you enter the "
                + "guest bedroom, you hear footsteps behind you getting "
                + "closer.", "Guest Bedroom", JOptionPane.INFORMATION_MESSAGE,
                guest);
          guestChoice = JOptionPane.showInputDialog(null, 
                "You have three options: Explore a \"Dresser\", "
                + "the queen \"Bed\", or enter the \"Common bathroom\". "
                       + "\n" + "Which do you choose?"); 
                
                        if (guestChoice.equals("Common bathroom")){
                            bthrm.commonBathroom();//calls common bathroom 
                            //selection method
                        }
                        
                        
                        else if (guestChoice.equals("Bed")){
                            JOptionPane.showMessageDialog(null, "You dive"
                                    + " under "
                            + "the covers, hoping whoever is following you"
                                    + " doesn't notice you. " + "\n" +
                                     "You will never"
                                    + " know whether it was your terrified"
                                    + " breathing or thumping heart beats"
                                    + " that gave you away." + "\n" +
                                    "You are murdered a second "
                                    + "later by a serial"
                                    + " killer who followed you into the tower."
                                    + "\n" + "GAME OVER"
                                    + "\n" + "Backpack Contents: NONE",

                                     "Guest Bedroom", 
                                    JOptionPane.INFORMATION_MESSAGE, bed
                            );
                        }
                        else if (guestChoice.equals("Dresser")){
                            JOptionPane.showMessageDialog(null, "You open one"
                                    + " of the dresser drawers and notice a key"
                                    + " inside." + "\n"+
                                    " You put the key in your back"
                                    + "pack and head home." + "\n"+
                                    "THE END"
                                    + "\n" + "Backpack Contents: Key",

                                    "Dresser",
                                    JOptionPane.INFORMATION_MESSAGE, key);
                        }
                          else {//Message for invalid inputs
        JOptionPane.showMessageDialog(null, "Sorry! Not a valid input" );   
}
    }
}
